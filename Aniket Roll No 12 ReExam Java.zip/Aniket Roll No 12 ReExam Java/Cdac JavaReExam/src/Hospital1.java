
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty.");
        }
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be a positive integer.");
        }
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty.");
        }
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be a positive integer.");
        }
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}

class Patient extends Person {
    private String patientId;
    private String ailment;

    public Patient(String name, int age, String patientId, String ailment) {
        super(name, age);
        if (patientId == null || patientId.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient ID cannot be null or empty.");
        }
        if (ailment == null || ailment.trim().isEmpty()) {
            throw new IllegalArgumentException("Ailment cannot be null or empty.");
        }
        this.patientId = patientId;
        this.ailment = ailment;
    }

    public Patient(String name, int age) {
        super(name, age);
        this.patientId = "Unknown";
        this.ailment = "Unknown";
    }


    public String getPatientId() {
        return patientId;
    }


    public void setPatientId(String patientId) {
        if (patientId == null || patientId.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient ID cannot be null or empty.");
        }
        this.patientId = patientId;
    }

 
    public String getAilment() {
        return ailment;
    }

    public void setAilment(String ailment) {
        if (ailment == null || ailment.trim().isEmpty()) {
            throw new IllegalArgumentException("Ailment cannot be null or empty.");
        }
        this.ailment = ailment;
    }

    @Override
    public String toString() {
        return "Patient{name='" + getName() + "', age=" + getAge() + ", patientId='" + patientId + "', ailment='" + ailment + "'}";
    }
}

public class Hospital1 {
    public static void main(String[] args) {
        try {

            Person person = new Person("Kapil Sangle", 20);
            System.out.println(person);

            Patient patient1 = new Patient("Prashant Sangle", 25, "P101", "Coroan");
            System.out.println(patient1);

            Patient patient2 = new Patient("Vaibhav Sangle", 30);
            System.out.println(patient2);

            patient2.setPatientId("P456");
            patient2.setAilment("Cold");
            System.out.println(patient2);

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
