import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private String id;
    private String title;
    private String author;
    private int copiesAvailable;

    public Book(String id, String title, String author, int copiesAvailable) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.copiesAvailable = copiesAvailable;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getCopiesAvailable() {
        return copiesAvailable;
    }

    @Override
    public String toString() {
        return "Book{id='" + id + "', title='" + title + "', author='" + author + "', copiesAvailable=" + copiesAvailable + "}";
    }
}

class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public boolean removeBook(String id) {
        for (Book book : books) {
            if (book.getId().equals(id)) {
                books.remove(book);
                return true;
            }
        }
        return false;
    }

    public List<Book> findBooksByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                result.add(book);
            }
        }
        return result;
    }

    public List<Book> findBooksWithFewerCopies(int copies) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getCopiesAvailable() < copies) {
                result.add(book);
            }
        }
        return result;
    }

    public List<Book> getAllBooks() {
        return books;
    }
}

public class LibraryManagement1 {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add a new book");
            System.out.println("2. Remove a book");
            System.out.println("3. Find all books by a given author");
            System.out.println("4. Find all books with fewer than a given number of copies available");
            System.out.println("5. Display all books");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter book ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter book author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter number of copies available: ");
                    int copiesAvailable = scanner.nextInt();
                    scanner.nextLine();

                    Book newBook = new Book(id, title, author, copiesAvailable);
                    library.addBook(newBook);
                    System.out.println("Book added successfully!");
                    break;

                case 2:
                    System.out.print("Enter book ID to remove: ");
                    String removeId = scanner.nextLine();
                    if (library.removeBook(removeId)) {
                        System.out.println("Book removed successfully!");
                    } else {
                        System.out.println("Book not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter author name: ");
                    String authorName = scanner.nextLine();
                    List<Book> booksByAuthor = library.findBooksByAuthor(authorName);
                    System.out.println("Books by " + authorName + ": " + booksByAuthor);
                    break;

                case 4:
                    System.out.print("Enter number of copies: ");
                    int copies = scanner.nextInt();
                    scanner.nextLine(); 
                    List<Book> booksWithFewerCopies = library.findBooksWithFewerCopies(copies);
                    System.out.println("Books with fewer than " + copies + " copies: " + booksWithFewerCopies);
                    break;

                case 5:
                    System.out.println("All books: " + library.getAllBooks());
                    break;

                case 6:
                    System.out.println("Exiting the program. Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
