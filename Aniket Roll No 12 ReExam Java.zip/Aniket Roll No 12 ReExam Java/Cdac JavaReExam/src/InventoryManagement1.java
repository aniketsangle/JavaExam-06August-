import java.util.HashMap;
import java.util.Map;

class ItemNotFoundException extends Exception {
    public ItemNotFoundException(String message) {
        super(message);
    }
}

class InsufficientStockException extends Exception {
    public InsufficientStockException(String message) {
        super(message);
    }
}

class InvalidQuantityException extends Exception {
    public InvalidQuantityException(String message) {
        super(message);
    }
}

class Inventory {
    private Map<String, Integer> items;

    public Inventory() {
        this.items = new HashMap<>();
    }

    public void addItem(String itemName, int quantity) throws InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException("Quantity must be greater than zero.");
        }
        items.put(itemName, items.getOrDefault(itemName, 0) + quantity);
    }

    public void removeItem(String itemName, int quantity) throws ItemNotFoundException, InsufficientStockException, InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException("Quantity must be greater than zero.");
        }
        if (!items.containsKey(itemName)) {
            throw new ItemNotFoundException("Item not found in inventory.");
        }
        if (items.get(itemName) < quantity) {
            throw new InsufficientStockException("Insufficient stock available.");
        }
        items.put(itemName, items.get(itemName) - quantity);
    }

    public int getStock(String itemName) throws ItemNotFoundException {
        if (!items.containsKey(itemName)) {
            throw new ItemNotFoundException("Item not found in inventory.");
        }
        return items.get(itemName);
    }

    public void displayInventory() {
        System.out.println("Current Inventory:");
        for (Map.Entry<String, Integer> entry : items.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}

public class InventoryManagement1 {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        try {
            inventory.addItem("Laptop", 10);
            inventory.addItem("Mouse", 50);
            inventory.addItem("Keyboard", 30);

            inventory.displayInventory();

            inventory.removeItem("Laptop", 5);
            inventory.removeItem("Mouse", 20);

            inventory.displayInventory();

            System.out.println("Stock of Laptop: " + inventory.getStock("Laptop"));
            
             //inventory.removeItem("Laptop", 10); 
             inventory.removeItem("Monitor", 5); //item not found
             //inventory.addItem("Printer", -5); //invalid quantity

        } catch (ItemNotFoundException | InsufficientStockException | InvalidQuantityException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
